public class PersonalInfo
{
private String name;
private String address;
private int age;
private String phoneNumber;
public PersonalInfo(String n, String a, int g, String p)
{
name = n;
address = a;
age = g;
phoneNumber = p;
}
public String getName()
{
return name;
}
public String getAddress()
{
return address;
}
public int getAge()
{
return age;
}
public String getphoneNumber()
{
return phoneNumber;
}
}